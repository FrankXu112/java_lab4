package lab4;

public class Professor extends Employee implements Comparable<Professor> {
	
	private String teachingMajor;

	public Professor(String name, String teachingMajor) {
		super(name);
		this.teachingMajor = teachingMajor;
	}
	
	/**
	 * @return the teachingMajor
	 */
	public String getTeachingMajor() {
		return teachingMajor;
	}


	/**
	 * @param teachingMajor the teachingMajor to set
	 */
	public void setTeachingMajor(String teachingMajor) {
		this.teachingMajor = teachingMajor;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((teachingMajor == null) ? 0 : teachingMajor.hashCode());
		return result;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Professor other = (Professor) obj;
		if (teachingMajor == null) {
			if (other.teachingMajor != null)
				return false;
		} else if (!teachingMajor.equals(other.teachingMajor))
			return false;
		return true;
	}


	@Override
	public double getOverTimePayRate() {
		return 2.0;
	}

	@Override
	public DressCode getDressCode() {
		// TODO Auto-generated method stub
		return DressCode.FANCY;
	}

	@Override
	public boolean isPaidSalary() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean postSecondaryEducationRequired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public String getWorkVerb() {
		// TODO Auto-generated method stub
		return "teach";
	}
	
	@Override
	public String toString() {
		return this.getName() + " teaches " + this.getTeachingMajor();
	}

	@Override
	public int compareTo(Professor ps) {
		return this.teachingMajor.compareTo(ps.teachingMajor);
	}

}
