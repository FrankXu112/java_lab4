package lab4;

public class Parent extends Employee implements Comparable<Parent> {
	
	private int numberOfHoursSpentPerWeekWithKids;

	public Parent(String name, int numberOfHoursSpentPerWeekWithKids) {
		super(name);
		this.numberOfHoursSpentPerWeekWithKids = numberOfHoursSpentPerWeekWithKids;
	}

	/**
	 * @return the numberOfHoursSpentPerWeekWithKids
	 */
	public int getNumberOfHoursSpentPerWeekWithKids() {
		return numberOfHoursSpentPerWeekWithKids;
	}

	/**
	 * @param numberOfHoursSpentPerWeekWithKids the numberOfHoursSpentPerWeekWithKids to set
	 */
	public void setNumberOfHoursSpentPerWeekWithKids(int numberOfHoursSpentPerWeekWithKids) {
		this.numberOfHoursSpentPerWeekWithKids = numberOfHoursSpentPerWeekWithKids;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + numberOfHoursSpentPerWeekWithKids;
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Parent other = (Parent) obj;
		if (numberOfHoursSpentPerWeekWithKids != other.numberOfHoursSpentPerWeekWithKids)
			return false;
		return true;
	}
	
	@Override
	public double getOverTimePayRate() {
		return -2.0;
	}

	@Override
	public DressCode getDressCode() {
		// TODO Auto-generated method stub
		return DressCode.ANYTHING;
	}

	@Override
	public boolean isPaidSalary() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean postSecondaryEducationRequired() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getWorkVerb() {
		// TODO Auto-generated method stub
		return "code";
	}
	
	@Override
	public String toString() {
		if(this.getNumberOfHoursSpentPerWeekWithKids() == 1) {
			return this.getName() + " spends " + this.getNumberOfHoursSpentPerWeekWithKids() + " hour/week with kids";
		}
		return this.getName() + " spends " + this.getNumberOfHoursSpentPerWeekWithKids() + " hours/week with kids";
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(Parent pa) {
		return (this.numberOfHoursSpentPerWeekWithKids - pa.numberOfHoursSpentPerWeekWithKids);
	}
	
	

}
