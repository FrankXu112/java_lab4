package lab4;

public interface Employable {
	public DressCode getDressCode();
	
	public boolean isPaidSalary();
	
	public boolean postSecondaryEducationRequired();
	
	public String getWorkVerb();
}
