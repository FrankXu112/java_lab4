package lab4;

import java.util.ArrayList;
import java.util.Collections;

public class Employees {
	private static ArrayList<Employee> employees;
	private static ArrayList<HockeyPlayer> hockeyplayers;
	private static ArrayList<Professor> professors;
	private static ArrayList<Parent> parents;
	private static ArrayList<GasStationAttendant> gasstationattendants;

	public Employees() {
		employees = new ArrayList<Employee>();
		employees.add(new HockeyPlayer("Wayne Gretzky", 894));
		employees.add(new HockeyPlayer("Who Ever", 0));
		employees.add(new HockeyPlayer("Brent Gretzky", 1));
		employees.add(new HockeyPlayer("Pavel Bure", 437));
		employees.add(new HockeyPlayer("Jason Bourne", 0));
		employees.add(new Professor("Albert Einstein", "Physics"));
		employees.add(new Professor("Alan Turing", "Computer Systems"));
		employees.add(new Professor("Richard Feynman", "Physics"));
		employees.add(new Professor("Tim Berners-Lee", "Computer Systems"));
		employees.add(new Professor("Kurt Godel", "Logic"));
		employees.add(new Parent("Tiger Woods", 1));
		employees.add(new Parent("Super Mom", 168));
		employees.add(new Parent("Lazy Larry", 20));
		employees.add(new Parent("Ex Hausted", 168));
		employees.add(new Parent("Super Dad", 167));
		employees.add(new GasStationAttendant("Joe Smith", 10));
		employees.add(new GasStationAttendant("Tony Baloney", 100));
		employees.add(new GasStationAttendant("Benjamin Franklin", 100));
		employees.add(new GasStationAttendant("Mary Fairy", 101));
		employees.add(new GasStationAttendant("Bee See", 1));	
		
		getHockeyPlayers();
		getProfessors();
		getParents();
		getGasStationAttendants();
	}
	
	public void getHockeyPlayers() {
		hockeyplayers = new ArrayList<HockeyPlayer>();
		hockeyplayers.add(new HockeyPlayer("Wayne Gretzky", 894));
		hockeyplayers.add(new HockeyPlayer("Who Ever", 0));
		hockeyplayers.add(new HockeyPlayer("Brent Gretzky", 1));
		hockeyplayers.add(new HockeyPlayer("Pavel Bure", 437));
		hockeyplayers.add(new HockeyPlayer("Jason Bourne", 0));
	}
	
	public void getProfessors() {
		professors = new ArrayList<Professor>();
		professors.add(new Professor("Albert Einstein", "Physics"));
		professors.add(new Professor("Alan Turing", "Computer Systems"));
		professors.add(new Professor("Richard Feynman", "Physics"));
		professors.add(new Professor("Tim Berners-Lee", "Computer Systems"));
		professors.add(new Professor("Kurt Godel", "Logic"));
	}
	
	public void getParents() {
		parents = new ArrayList<Parent>();
		parents.add(new Parent("Tiger Woods", 1));
		parents.add(new Parent("Super Mom", 168));
		parents.add(new Parent("Lazy Larry", 20));
		parents.add(new Parent("Ex Hausted", 168));
		parents.add(new Parent("Super Dad", 167));
	}
	
	public void getGasStationAttendants() {
		gasstationattendants = new ArrayList<GasStationAttendant>();
		gasstationattendants.add(new GasStationAttendant("Joe Smith", 10));
		gasstationattendants.add(new GasStationAttendant("Tony Baloney", 100));
		gasstationattendants.add(new GasStationAttendant("Benjamin Franklin", 100));
		gasstationattendants.add(new GasStationAttendant("Mary Fairy", 101));
		gasstationattendants.add(new GasStationAttendant("Bee See", 1));	
	}
	
	
	public static void main(String[] args) {
		Employees ep = new Employees();
		for(Employee employee: employees) {
			System.out.println(employee);
		}
		System.out.println();
		
		for(HockeyPlayer hockeyplayer: hockeyplayers) {
			System.out.println(hockeyplayer);
		}
		System.out.println();
		Collections.sort(hockeyplayers);
		for(HockeyPlayer hockeyplayer: hockeyplayers) {
			System.out.println(hockeyplayer);
		}
		System.out.println();
		
		for(Professor professor: professors) {
			System.out.println(professor);
		}
		Collections.sort(professors);
		System.out.println();
		for(Professor professor: professors) {
			System.out.println(professor);
		}
		System.out.println();
		
		for(Parent parent: parents) {
			System.out.println(parent);
		}
		System.out.println();
		Collections.sort(parents);
		for(Parent parent: parents) {
			System.out.println(parent);
		}
		System.out.println();
		
		for(GasStationAttendant gasstationattendant: gasstationattendants) {
			System.out.println(gasstationattendant);
		}
		System.out.println();
		Collections.sort(gasstationattendants);
		for(GasStationAttendant gasstationattendant: gasstationattendants) {
			System.out.println(gasstationattendant);
		}
	}
}
